# Object-Detection-OpenCV
Object Detection for OpenCV  Internship Purpose
THE SPARKS FOUNDATION INTERNSHIP  #GRIPAUGUST21
# Youtube Link
https://youtu.be/5xTQOyvH0VY
